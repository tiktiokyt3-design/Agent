import logging

from database import users
from keyboards.menus import inactive_menu
from services import subscription
from services.agent import ask_agent, extract_command

MESSAGE_LIMIT = 4096


def register(bot):
    @bot.message_handler(
        content_types=["text"], func=lambda message: not message.text.startswith("/")
    )
    def agent_message(message):
        user = users.ensure(message.from_user)
        name = user["agent_name"]

        if not name:
            bot.send_message(
                message.chat.id, "🤖 Сначала назови своего агента командой /agent"
            )
            return

        command = extract_command(message.text, name)
        if command is None:
            return

        if not subscription.is_active(user):
            bot.send_message(
                message.chat.id,
                "⛔ Подписка не активна. Активируй ключ или купи подписку.",
                reply_markup=inactive_menu(),
            )
            return

        if not command:
            bot.send_message(message.chat.id, f"👂 {name} слушает. Что нужно?")
            return

        bot.send_chat_action(message.chat.id, "typing")
        try:
            answer = ask_agent(command, name)
        except Exception:
            logging.exception("Agent error")
            bot.send_message(
                message.chat.id, "⚠️ Агент временно недоступен. Попробуй позже."
            )
            return

        answer = answer or "🤔 Пустой ответ, попробуй переформулировать."
        for start in range(0, len(answer), MESSAGE_LIMIT):
            bot.send_message(message.chat.id, answer[start : start + MESSAGE_LIMIT])
