import html

from database import users
from keyboards.menus import main_menu
from services import subscription
from utils.formatting import format_date
from utils.telegram import is_admin, show


def main_text(user, first_name):
    if subscription.is_active(user):
        status = f"✅ Подписка активна до {format_date(user['sub_until'])}"
    else:
        status = "❌ Подписка не активна"
    return (
        "🤖 <b>AI Агент</b>\n"
        "Твой персональный ИИ-помощник в Telegram\n\n"
        "✨ <b>Возможности</b>\n"
        "• Свой агент с любым именем\n"
        "• Отвечает только когда позвать его по имени\n"
        "• Гибкие подписки от 1 до 30 дней\n\n"
        f"Привет, <b>{html.escape(first_name)}</b>!\n"
        f"{status}\n\n"
        "Выбери раздел 👇"
    )


def open_main(bot, event):
    user = users.ensure(event.from_user)
    show(
        bot,
        event,
        main_text(user, event.from_user.first_name or "друг"),
        main_menu(is_admin(event.from_user.id)),
    )


def register(bot):
    @bot.message_handler(commands=["start"])
    def start_command(message):
        open_main(bot, message)

    @bot.callback_query_handler(func=lambda call: call.data == "main")
    def main_callback(call):
        open_main(bot, call)
