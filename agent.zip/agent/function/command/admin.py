import time

from config.plans import PLANS
from database import keys, users
from function.command.cabinet import profile_text
from keyboards.menus import admin_menu, back, plans_menu
from services import subscription
from utils.formatting import days_label
from utils.telegram import is_admin, is_command, prompt, retry, show

PANEL_TEXT = "🛠 <b>Админ панель</b>\n\nВыбери действие 👇"
BACK_TO_PANEL = back("admin", "⬅️ Админ панель")


def open_panel(bot, event):
    show(bot, event, PANEL_TEXT, admin_menu())


def show_stats(bot, call):
    total_keys = keys.count_total()
    free_keys = keys.count_unused()
    show(
        bot,
        call,
        "📊 <b>Статистика</b>\n\n"
        f"👥 Пользователей: <b>{users.count_total()}</b>\n"
        f"💎 С активной подпиской: <b>{users.count_active()}</b>\n\n"
        f"🔑 Ключей создано: <b>{total_keys}</b>\n"
        f"✅ Использовано: <b>{total_keys - free_keys}</b>\n"
        f"🆓 Свободно: <b>{free_keys}</b>",
        BACK_TO_PANEL,
    )


def choose_key_plan(bot, call):
    show(
        bot,
        call,
        "🔑 <b>Создание ключа</b>\n\nВыбери срок 👇",
        plans_menu("admin:key", "admin", False),
    )


def create_key(bot, call, days):
    days = int(days)
    if days not in PLANS:
        return
    key = subscription.create_key(days)
    bot.answer_callback_query(call.id, "Ключ создан")
    bot.send_message(
        call.message.chat.id,
        f"🔑 Ключ на <b>{days_label(days)}</b>:\n\n<code>{key}</code>",
        parse_mode="HTML",
    )


def show_keys(bot, call):
    free = keys.list_unused()
    if free:
        lines = "\n".join(
            f"<code>{item['key']}</code> — {days_label(item['days'])}" for item in free
        )
        text = f"📋 <b>Свободные ключи</b>\n\n{lines}"
    else:
        text = "📋 Свободных ключей нет"
    show(bot, call, text, BACK_TO_PANEL)


def ask_user_id(bot, call, action):
    text = "🆔 Отправь ID пользователя:"
    prompt(bot, call, text, lambda message: receive_user_id(bot, message, action), BACK_TO_PANEL)


def receive_user_id(bot, message, action):
    if is_command(bot, message) or not is_admin(message.from_user.id):
        return
    text = (message.text or "").strip()
    user = users.get(int(text)) if text.isdigit() else None
    if user is None:
        retry(
            bot,
            message,
            "❌ Пользователь не найден. Отправь другой ID.",
            lambda m: receive_user_id(bot, m, action),
            BACK_TO_PANEL,
        )
        return
    action(bot, message, user)


def show_user(bot, message, user):
    show(bot, message, profile_text(user, "🔍 <b>Пользователь</b>"), BACK_TO_PANEL)


def choose_give_plan(bot, message, user):
    show(
        bot,
        message,
        f"🎁 Выдать подписку пользователю <code>{user['user_id']}</code>.\n\nВыбери срок 👇",
        plans_menu(f"admin:grant:{user['user_id']}", "admin", False),
    )


def grant(bot, call, user_id, days):
    user_id, days = int(user_id), int(days)
    if days not in PLANS or users.get(user_id) is None:
        return
    subscription.grant(user_id, days)
    show(
        bot,
        call,
        f"✅ Пользователю <code>{user_id}</code> выдано: <b>{days_label(days)}</b>",
        BACK_TO_PANEL,
    )
    try:
        bot.send_message(user_id, f"🎁 Тебе выдана подписка на {days_label(days)}!")
    except Exception:
        pass


def revoke(bot, message, user):
    subscription.revoke(user["user_id"])
    show(
        bot,
        message,
        f"🚫 Подписка пользователя <code>{user['user_id']}</code> отключена",
        BACK_TO_PANEL,
    )


def ask_broadcast(bot, call):
    prompt(
        bot,
        call,
        "📢 Отправь текст рассылки:",
        lambda message: send_broadcast(bot, message),
        BACK_TO_PANEL,
    )


def send_broadcast(bot, message):
    if is_command(bot, message) or not is_admin(message.from_user.id):
        return
    if not message.text:
        retry(bot, message, "❌ Нужен текст. Отправь ещё раз.", lambda m: send_broadcast(bot, m), BACK_TO_PANEL)
        return
    sent = failed = 0
    for user_id in users.all_ids():
        try:
            bot.send_message(user_id, message.text)
            sent += 1
        except Exception:
            failed += 1
        time.sleep(0.05)
    show(
        bot,
        message,
        f"📢 <b>Рассылка завершена</b>\n\n✅ Доставлено: {sent}\n❌ Ошибок: {failed}",
        BACK_TO_PANEL,
    )


def register(bot):
    @bot.message_handler(commands=["admin"])
    def admin_command(message):
        if is_admin(message.from_user.id):
            open_panel(bot, message)

    @bot.callback_query_handler(
        func=lambda call: call.data == "admin" or call.data.startswith("admin:")
    )
    def admin_callback(call):
        if not is_admin(call.from_user.id):
            bot.answer_callback_query(call.id, "⛔ Нет доступа", show_alert=True)
            return
        _, _, rest = call.data.partition(":")
        action, *args = rest.split(":") if rest else ["menu"]
        if action == "stats":
            show_stats(bot, call)
        elif action == "genkey":
            choose_key_plan(bot, call)
        elif action == "key":
            create_key(bot, call, *args)
        elif action == "keys":
            show_keys(bot, call)
        elif action == "give":
            ask_user_id(bot, call, lambda b, m, u: choose_give_plan(b, m, u))
        elif action == "grant":
            grant(bot, call, *args)
        elif action == "revoke":
            ask_user_id(bot, call, revoke)
        elif action == "user":
            ask_user_id(bot, call, show_user)
        elif action == "broadcast":
            ask_broadcast(bot, call)
        else:
            open_panel(bot, call)
