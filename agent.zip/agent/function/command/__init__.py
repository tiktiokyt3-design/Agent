from function.command import admin, agent_name, buy, cabinet, help, start


def register_all(bot):
    for module in (start, cabinet, buy, agent_name, help, admin):
        module.register(bot)
