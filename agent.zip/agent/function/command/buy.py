from config.plans import CURRENCY, PLANS
from keyboards.menus import plan_menu, plans_menu
from utils.formatting import days_label
from utils.telegram import show


def open_plans(bot, event):
    lines = "\n".join(
        f"• {days_label(days)} — <b>{price} {CURRENCY}</b>"
        for days, price in PLANS.items()
    )
    show(
        bot,
        event,
        f"💎 <b>Подписка</b>\n\n{lines}\n\nВыбери тариф 👇",
        plans_menu("buy", "main", True),
    )


def open_plan(bot, call, days):
    show(
        bot,
        call,
        f"💎 <b>Подписка на {days_label(days)}</b>\n"
        f"💰 Цена: <b>{PLANS[days]} {CURRENCY}</b>\n\n"
        "⚠️ Онлайн-оплата пока недоступна.\n"
        "Ключ можно получить у администратора, "
        "а затем активировать в личном кабинете."
        "Администратор - @w1zzyosint",
        plan_menu(),
    )


def register(bot):
    @bot.message_handler(commands=["buy"])
    def buy_command(message):
        open_plans(bot, message)

    @bot.callback_query_handler(
        func=lambda call: call.data == "buy" or call.data.startswith("buy:")
    )
    def buy_callback(call):
        value = call.data.partition(":")[2]
        if value.isdigit() and int(value) in PLANS:
            open_plan(bot, call, int(value))
        else:
            open_plans(bot, call)
