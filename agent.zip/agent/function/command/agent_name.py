import html

from database import users
from keyboards.menus import back, cabinet_menu
from services.agent import is_valid_name
from utils.telegram import is_command, prompt, retry, show

ASK_TEXT = (
    "✏️ <b>Как назвать твоего агента?</b>\n\n"
    "Отправь имя одним словом, от 2 до 20 символов."
)
INVALID_TEXT = "❌ Имя должно быть одним словом, от 2 до 20 символов. Попробуй ещё раз."


def ask_name(bot, event):
    users.ensure(event.from_user)
    prompt(bot, event, ASK_TEXT, lambda message: receive_name(bot, message), back("cabinet"))


def receive_name(bot, message):
    if is_command(bot, message):
        return
    name = (message.text or "").strip()
    if not is_valid_name(name):
        retry(bot, message, INVALID_TEXT, lambda m: receive_name(bot, m), back("cabinet"))
        return
    users.ensure(message.from_user)
    users.set_agent_name(message.from_user.id, name)
    safe_name = html.escape(name)
    show(
        bot,
        message,
        f"✅ Агент назван <b>{safe_name}</b>\n\n"
        f"Теперь обращайся к нему так:\n<i>{safe_name}, расскажи анекдот</i>",
        cabinet_menu(),
    )


def register(bot):
    @bot.message_handler(commands=["agent"])
    def agent_command(message):
        ask_name(bot, message)
