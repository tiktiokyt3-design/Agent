import html

from database import users
from function.command.agent_name import ask_name
from keyboards.menus import back, cabinet_menu
from services import subscription
from utils.formatting import days_label, format_date, time_left
from utils.telegram import is_command, prompt, retry, show

ASK_KEY_TEXT = "🔑 <b>Активация ключа</b>\n\nОтправь ключ подписки одним сообщением."


def profile_text(user, title="👤 <b>Личный кабинет</b>"):
    username = f"@{html.escape(user['username'])}" if user["username"] else "—"
    agent = html.escape(user["agent_name"]) if user["agent_name"] else "не назван"
    key = f"<code>{user['sub_key']}</code>" if user["sub_key"] else "—"
    if subscription.is_active(user):
        status = (
            f"✅ активна до {format_date(user['sub_until'])}\n"
            f"⏳ Осталось: {time_left(user['sub_until'])}"
        )
    else:
        status = "❌ не активна"
    return (
        f"{title}\n\n"
        f"🆔 ID: <code>{user['user_id']}</code>\n"
        f"👤 Юзер: {username}\n"
        f"🤖 Агент: {agent}\n"
        f"🔑 Ключ: {key}\n"
        f"📅 Регистрация: {format_date(user['registered_at'])}\n\n"
        f"💎 Подписка: {status}"
    )


def open_cabinet(bot, event):
    user = users.ensure(event.from_user)
    show(bot, event, profile_text(user), cabinet_menu())


def ask_key(bot, event):
    users.ensure(event.from_user)
    prompt(bot, event, ASK_KEY_TEXT, lambda message: receive_key(bot, message), back("cabinet"))


def receive_key(bot, message):
    if is_command(bot, message):
        return
    users.ensure(message.from_user)
    status, days = subscription.activate_key(message.from_user.id, message.text or "")
    if status == "ok":
        show(
            bot,
            message,
            f"✅ Ключ активирован!\nДобавлено: <b>{days_label(days)}</b>",
            cabinet_menu(),
        )
        return
    text = (
        "⚠️ Этот ключ уже использован. Отправь другой."
        if status == "used"
        else "❌ Ключ не найден. Проверь его и отправь ещё раз."
    )
    retry(bot, message, text, lambda m: receive_key(bot, m), back("cabinet"))


def register(bot):
    @bot.message_handler(commands=["cabinet"])
    def cabinet_command(message):
        open_cabinet(bot, message)

    @bot.callback_query_handler(
        func=lambda call: call.data == "cabinet" or call.data.startswith("cabinet:")
    )
    def cabinet_callback(call):
        action = call.data.partition(":")[2]
        if action == "key":
            ask_key(bot, call)
        elif action == "agent":
            ask_name(bot, call)
        else:
            open_cabinet(bot, call)
