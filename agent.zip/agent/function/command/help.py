from config.plans import CURRENCY, PLANS
from keyboards.menus import back
from utils.formatting import days_label
from utils.telegram import show


def about_text():
    prices = "\n".join(
        f"• {days_label(days)} — {price} {CURRENCY}" for days, price in PLANS.items()
    )
    return (
        "ℹ️ <b>О боте</b>\n\n"
        "Это персональный ИИ-агент. Ты сам придумываешь ему имя, "
        "и он отвечает только тогда, когда к нему обратились по имени.\n\n"
        "📖 <b>Как начать</b>\n"
        "1. Купи подписку и получи ключ\n"
        "2. В личном кабинете активируй ключ\n"
        "3. Назови своего агента\n"
        "4. Пиши в чат: <i>Имя, твой вопрос</i>\n\n"
        f"💎 <b>Тарифы</b>\n{prices}\n\n"
        "⌨️ <b>Команды</b>\n"
        "/start — главное меню\n"
        "/cabinet — личный кабинет\n"
        "/buy — купить подписку\n"
        "/agent — назвать агента\n"
        "/help — о боте"
    )


def open_about(bot, event):
    show(bot, event, about_text(), back())


def register(bot):
    @bot.message_handler(commands=["help"])
    def help_command(message):
        open_about(bot, message)

    @bot.callback_query_handler(func=lambda call: call.data == "about")
    def about_callback(call):
        open_about(bot, call)
