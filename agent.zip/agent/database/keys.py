import sqlite3
import time

from database.connection import connect


def add(key, days):
    try:
        with connect() as conn:
            conn.execute(
                "INSERT INTO keys (key, days, created_at) VALUES (?, ?, ?)",
                (key, days, int(time.time())),
            )
    except sqlite3.IntegrityError:
        return False
    return True


def get(key):
    with connect() as conn:
        row = conn.execute("SELECT * FROM keys WHERE key = ?", (key,)).fetchone()
    return dict(row) if row else None


def mark_used(key, user_id):
    with connect() as conn:
        cursor = conn.execute(
            "UPDATE keys SET used_by = ?, used_at = ? WHERE key = ? AND used_by IS NULL",
            (user_id, int(time.time()), key),
        )
    return cursor.rowcount == 1


def count_total():
    with connect() as conn:
        return conn.execute("SELECT COUNT(*) FROM keys").fetchone()[0]


def count_unused():
    with connect() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM keys WHERE used_by IS NULL"
        ).fetchone()[0]


def list_unused(limit=30):
    with connect() as conn:
        rows = conn.execute(
            "SELECT * FROM keys WHERE used_by IS NULL ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]
