import time

from database.connection import connect


def ensure(tg_user):
    with connect() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO users (user_id, username, registered_at) VALUES (?, ?, ?)",
            (tg_user.id, tg_user.username, int(time.time())),
        )
        conn.execute(
            "UPDATE users SET username = ? WHERE user_id = ?",
            (tg_user.username, tg_user.id),
        )
        row = conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (tg_user.id,)
        ).fetchone()
    return dict(row)


def get(user_id):
    with connect() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE user_id = ?", (user_id,)
        ).fetchone()
    return dict(row) if row else None


def set_agent_name(user_id, name):
    with connect() as conn:
        conn.execute(
            "UPDATE users SET agent_name = ? WHERE user_id = ?", (name, user_id)
        )


def set_subscription(user_id, until, key=None):
    with connect() as conn:
        conn.execute(
            "UPDATE users SET sub_until = ?, sub_key = COALESCE(?, sub_key) WHERE user_id = ?",
            (until, key, user_id),
        )


def all_ids():
    with connect() as conn:
        rows = conn.execute("SELECT user_id FROM users").fetchall()
    return [row["user_id"] for row in rows]


def count_total():
    with connect() as conn:
        return conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]


def count_active():
    with connect() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM users WHERE sub_until > ?", (int(time.time()),)
        ).fetchone()[0]
