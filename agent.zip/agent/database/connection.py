import sqlite3
from contextlib import contextmanager

from config.config_agent import DB_PATH


@contextmanager
def connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                sub_key TEXT,
                sub_until INTEGER NOT NULL DEFAULT 0,
                agent_name TEXT,
                registered_at INTEGER NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS keys (
                key TEXT PRIMARY KEY,
                days INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                used_by INTEGER,
                used_at INTEGER
            )
            """
        )
