from pathlib import Path

TOKEN_BOT = "8836760253:AAFViHd18OP5cpIoQDLj9XthFF8ns1ZCIeM"
API_AGENT = "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"
MODEL = "gpt-4o-mini"

ADMIN_IDS = [6994614587]

DB_PATH = Path(__file__).resolve().parent.parent / "bot.db"
