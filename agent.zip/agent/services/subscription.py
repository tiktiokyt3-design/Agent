import secrets
import time

from database import keys, users

ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
DAY = 86400


def generate_key():
    return "-".join(
        "".join(secrets.choice(ALPHABET) for _ in range(4)) for _ in range(4)
    )


def create_key(days):
    while True:
        key = generate_key()
        if keys.add(key, days):
            return key


def is_active(user):
    return user["sub_until"] > time.time()


def extended_until(user_id, days):
    user = users.get(user_id)
    start = max(int(time.time()), user["sub_until"])
    return start + days * DAY


def activate_key(user_id, raw_key):
    key = raw_key.strip().upper()
    record = keys.get(key)
    if record is None:
        return "invalid", 0
    if not keys.mark_used(key, user_id):
        return "used", 0
    users.set_subscription(user_id, extended_until(user_id, record["days"]), key)
    return "ok", record["days"]


def grant(user_id, days):
    users.set_subscription(user_id, extended_until(user_id, days))


def revoke(user_id):
    users.set_subscription(user_id, 0)
