import re

import requests

from config.config_agent import API_AGENT, MODEL

OPENAI_URL = "https://api.openai.com/v1/responses"
NAME_PATTERN = re.compile(r"^[\w-]{2,20}$")


def is_valid_name(name):
    return bool(NAME_PATTERN.match(name))


def extract_command(text, agent_name):
    pattern = rf"^\s*{re.escape(agent_name)}(?!\w)[\s,.:;!?\-—]*(.*)$"
    match = re.match(pattern, text, re.IGNORECASE | re.DOTALL)
    if match is None:
        return None
    return match.group(1).strip()


def ask_agent(text, agent_name):
    headers = {
        "Authorization": f"Bearer {API_AGENT.strip()}",
        "Content-Type": "application/json",
    }
    data = {
        "model": MODEL,
        "instructions": f"Тебя зовут {agent_name}. Ты персональный ИИ-агент пользователя.",
        "input": text,
    }

    response = requests.post(OPENAI_URL, headers=headers, json=data, timeout=60)

    if not response.ok:
        try:
            message = response.json().get("error", {}).get("message", response.text)
        except ValueError:
            message = response.text
        raise RuntimeError(f"OpenAI API {response.status_code}: {message}")

    result = response.json()

    if "output_text" in result:
        return result["output_text"]

    for item in result.get("output", []):
        for content in item.get("content", []):
            if content.get("type") == "output_text":
                return content.get("text", "")

    raise RuntimeError(f"Не найден текст в ответе API: {result}")
