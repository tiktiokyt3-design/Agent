from telebot.apihelper import ApiTelegramException
from telebot.types import CallbackQuery

from config.config_agent import ADMIN_IDS


def is_admin(user_id):
    return user_id in ADMIN_IDS


def chat_id(event):
    if isinstance(event, CallbackQuery):
        return event.message.chat.id
    return event.chat.id


def show(bot, event, text, markup=None):
    bot.clear_step_handler_by_chat_id(chat_id(event))
    if isinstance(event, CallbackQuery):
        bot.answer_callback_query(event.id)
        try:
            bot.edit_message_text(
                text,
                event.message.chat.id,
                event.message.message_id,
                reply_markup=markup,
                parse_mode="HTML",
            )
        except ApiTelegramException as error:
            if "message is not modified" not in str(error):
                raise
        return
    bot.send_message(event.chat.id, text, reply_markup=markup, parse_mode="HTML")


def prompt(bot, event, text, handler, markup=None):
    show(bot, event, text, markup)
    bot.register_next_step_handler_by_chat_id(chat_id(event), handler)


def retry(bot, message, text, handler, markup=None):
    bot.send_message(message.chat.id, text, reply_markup=markup, parse_mode="HTML")
    bot.register_next_step_handler_by_chat_id(message.chat.id, handler)


def is_command(bot, message):
    if message.text and message.text.startswith("/"):
        bot.process_new_messages([message])
        return True
    return False
