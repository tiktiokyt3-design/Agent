import logging

import telebot
from telebot.types import BotCommand

from config.config_agent import TOKEN_BOT
from database.connection import init_db
from function import agent_chat
from function.command import register_all

logging.basicConfig(level=logging.INFO)

bot = telebot.TeleBot(TOKEN_BOT)


def main():
    init_db()
    register_all(bot)
    agent_chat.register(bot)
    bot.set_my_commands(
        [
            BotCommand("start", "Главное меню"),
            BotCommand("cabinet", "Личный кабинет"),
            BotCommand("buy", "Купить подписку"),
            BotCommand("agent", "Назвать агента"),
            BotCommand("help", "О боте"),
        ]
    )
    print("Бот запущен")
    bot.infinity_polling(skip_pending=True)


if __name__ == "__main__":
    main()
