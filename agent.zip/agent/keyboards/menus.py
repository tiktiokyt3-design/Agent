from telebot.types import InlineKeyboardButton as Button
from telebot.types import InlineKeyboardMarkup

from config.plans import CURRENCY, PLANS
from utils.formatting import days_label


def build(rows):
    markup = InlineKeyboardMarkup()
    for row in rows:
        markup.row(*row)
    return markup


def main_menu(is_admin=False):
    rows = [
        [Button("👤 Личный кабинет", callback_data="cabinet")],
        [Button("💎 Купить подписку", callback_data="buy")],
        [Button("ℹ️ О боте", callback_data="about")],
    ]
    if is_admin:
        rows.append([Button("🛠 Админ панель", callback_data="admin")])
    return build(rows)


def back(target="main", label="⬅️ Назад"):
    return build([[Button(label, callback_data=target)]])


def cabinet_menu():
    return build(
        [
            [Button("🔑 Активировать ключ", callback_data="cabinet:key")],
            [Button("✏️ Назвать агента", callback_data="cabinet:agent")],
            [Button("💎 Купить подписку", callback_data="buy")],
            [Button("⬅️ Назад", callback_data="main")],
        ]
    )


def plans_menu(prefix, target, with_price):
    rows = []
    for days, price in PLANS.items():
        label = days_label(days)
        if with_price:
            label = f"{label} — {price} {CURRENCY}"
        rows.append([Button(label, callback_data=f"{prefix}:{days}")])
    rows.append([Button("⬅️ Назад", callback_data=target)])
    return build(rows)


def plan_menu():
    return build(
        [
            [Button("🔑 У меня есть ключ", callback_data="cabinet:key")],
            [Button("⬅️ К тарифам", callback_data="buy")],
        ]
    )


def inactive_menu():
    return build(
        [
            [Button("🔑 Активировать ключ", callback_data="cabinet:key")],
            [Button("💎 Купить подписку", callback_data="buy")],
        ]
    )


def admin_menu():
    return build(
        [
            [Button("📊 Статистика", callback_data="admin:stats")],
            [Button("🔑 Создать ключ", callback_data="admin:genkey")],
            [Button("📋 Свободные ключи", callback_data="admin:keys")],
            [Button("🎁 Выдать подписку", callback_data="admin:give")],
            [Button("🚫 Забрать подписку", callback_data="admin:revoke")],
            [Button("🔍 Пользователь", callback_data="admin:user")],
            [Button("📢 Рассылка", callback_data="admin:broadcast")],
            [Button("⬅️ В меню", callback_data="main")],
        ]
    )
